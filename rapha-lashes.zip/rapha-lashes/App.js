import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  TextInput,
  ScrollView,
  Alert,
  Modal,
  Linking,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Dados da Profissional
const PROFISSIONAL = {
  nome: 'Raphaella Redó',
  telefone: '5511941696682',
  loja: 'Rapha Lashes',
  instagram: '@raphalashes',
};

// Serviços de Cílios
const SERVICOS = [
  {
    id: '1',
    nome: 'Volume Brasileiro',
    descricao: 'Cílios mais volumosos e dramáticos',
    duracao: '2h',
    preco: 'R$ 180',
    icon: '👁️',
  },
  {
    id: '2',
    nome: 'Fio a Fio Clássico',
    descricao: 'Alongamento natural e elegante',
    duracao: '1h30',
    preco: 'R$ 150',
    icon: '✨',
  },
  {
    id: '3',
    nome: 'Volume Russo',
    descricao: 'Efeito mega volume, super glamuroso',
    duracao: '2h30',
    preco: 'R$ 220',
    icon: '💎',
  },
  {
    id: '4',
    nome: 'Manutenção',
    descricao: 'Preenchimento de falhas',
    duracao: '1h',
    preco: 'R$ 90',
    icon: '🔄',
  },
  {
    id: '5',
    nome: 'Remoção de Cílios',
    descricao: 'Remoção profissional e segura',
    duracao: '30min',
    preco: 'R$ 50',
    icon: '🧹',
  },
];

// Horários disponíveis
const HORARIOS = [
  '09:00', '10:00', '11:00', '12:00',
  '14:00', '15:00', '16:00', '17:00', '18:00'
];

// Datas próximas (próximos 7 dias)
const gerarDatas = () => {
  const datas = [];
  const hoje = new Date();
  
  for (let i = 1; i <= 7; i++) {
    const data = new Date(hoje);
    data.setDate(hoje.getDate() + i);
    
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    const meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    
    datas.push({
      id: i.toString(),
      dia: data.getDate(),
      mes: meses[data.getMonth()],
      diaSemana: diasSemana[data.getDay()],
      dataCompleta: data.toISOString().split('T')[0],
    });
  }
  return datas;
};

export default function App() {
  const [agendamentos, setAgendamentos] = useState([]);
  const [modoAdmin, setModoAdmin] = useState(false);
  const [senhaAdmin, setSenhaAdmin] = useState('');
  const [modalLoginVisible, setModalLoginVisible] = useState(false);
  
  const [modalAgendamentoVisible, setModalAgendamentoVisible] = useState(false);
  const [servicoSelecionado, setServicoSelecionado] = useState(null);
  const [dataSelecionada, setDataSelecionada] = useState(null);
  const [horarioSelecionado, setHorarioSelecionado] = useState(null);
  const [nomeCliente, setNomeCliente] = useState('');
  const [telefone, setTelefone] = useState('');
  const [observacao, setObservacao] = useState('');
  
  const [telefoneBusca, setTelefoneBusca] = useState('');
  const [agendamentosCliente, setAgendamentosCliente] = useState([]);
  const [mostrarMeusAgendamentos, setMostrarMeusAgendamentos] = useState(false);
  
  const [datasDisponiveis] = useState(gerarDatas());

  useEffect(() => {
    carregarAgendamentos();
  }, []);

  useEffect(() => {
    salvarAgendamentos();
  }, [agendamentos]);

  const carregarAgendamentos = async () => {
    try {
      const saved = await AsyncStorage.getItem('@agendamentos_rapha');
      if (saved !== null) {
        setAgendamentos(JSON.parse(saved));
      }
    } catch (error) {
      console.error('Erro ao carregar:', error);
    }
  };

  const salvarAgendamentos = async () => {
    try {
      await AsyncStorage.setItem('@agendamentos_rapha', JSON.stringify(agendamentos));
    } catch (error) {
      console.error('Erro ao salvar:', error);
    }
  };

  const fazerLoginAdmin = () => {
    if (senhaAdmin === 'rapha2024') {
      setModoAdmin(true);
      setModalLoginVisible(false);
      setSenhaAdmin('');
      Alert.alert('Bem-vinda!', `Olá ${PROFISSIONAL.nome}, modo profissional ativado`);
    } else {
      Alert.alert('Erro', 'Senha incorreta');
    }
  };

  const fazerLogoutAdmin = () => {
    setModoAdmin(false);
    Alert.alert('Logout', 'Modo profissional desativado');
  };

  const abrirWhatsApp = (mensagem = '') => {
    let url = `https://wa.me/${PROFISSIONAL.telefone}`;
    if (mensagem) {
      url += `?text=${encodeURIComponent(mensagem)}`;
    }
    Linking.openURL(url).catch(() => {
      Alert.alert('Erro', 'Não foi possível abrir o WhatsApp');
    });
  };

  const fazerAgendamento = () => {
    if (!nomeCliente.trim()) {
      Alert.alert('Atenção', 'Por favor, digite seu nome');
      return;
    }
    if (!telefone.trim()) {
      Alert.alert('Atenção', 'Por favor, digite seu telefone');
      return;
    }
    if (!servicoSelecionado) {
      Alert.alert('Atenção', 'Por favor, selecione um serviço');
      return;
    }
    if (!dataSelecionada) {
      Alert.alert('Atenção', 'Por favor, selecione uma data');
      return;
    }
    if (!horarioSelecionado) {
      Alert.alert('Atenção', 'Por favor, selecione um horário');
      return;
    }

    const horarioOcupado = agendamentos.some(
      ag => ag.data === dataSelecionada.dataCompleta && 
            ag.horario === horarioSelecionado
    );

    if (horarioOcupado) {
      Alert.alert('Horário indisponível', 'Este horário já foi reservado. Escolha outro horário.');
      return;
    }

    const novoAgendamento = {
      id: Date.now().toString(),
      cliente: nomeCliente,
      telefone: telefone,
      servico: servicoSelecionado,
      data: dataSelecionada.dataCompleta,
      dataFormatada: `${dataSelecionada.diaSemana}, ${dataSelecionada.dia} de ${dataSelecionada.mes}`,
      horario: horarioSelecionado,
      observacao: observacao,
      status: 'confirmado',
      criadoEm: new Date().toISOString(),
    };

    setAgendamentos([...agendamentos, novoAgendamento]);
    
    setModalAgendamentoVisible(false);
    setServicoSelecionado(null);
    setDataSelecionada(null);
    setHorarioSelecionado(null);
    setNomeCliente('');
    setTelefone('');
    setObservacao('');
    
    Alert.alert('Sucesso!', `Seu agendamento na ${PROFISSIONAL.loja} foi confirmado!`);
  };

  const cancelarAgendamentoCliente = (id) => {
    Alert.alert(
      'Cancelar agendamento',
      'Tem certeza que deseja cancelar?',
      [
        { text: 'Não', style: 'cancel' },
        { 
          text: 'Sim', 
          onPress: () => {
            setAgendamentos(agendamentos.filter(item => item.id !== id));
            buscarAgendamentosPorTelefone();
            Alert.alert('Cancelado', 'Agendamento cancelado com sucesso');
          }
        }
      ]
    );
  };

  const cancelarAgendamentoAdmin = (id) => {
    Alert.alert(
      'Cancelar agendamento',
      'Cancelar este agendamento?',
      [
        { text: 'Não', style: 'cancel' },
        { 
          text: 'Sim', 
          onPress: () => {
            setAgendamentos(agendamentos.filter(item => item.id !== id));
            Alert.alert('Cancelado', 'Agendamento cancelado');
          }
        }
      ]
    );
  };

  const buscarAgendamentosPorTelefone = () => {
    if (!telefoneBusca.trim()) {
      Alert.alert('Atenção', 'Digite seu telefone para buscar');
      return;
    }
    
    const encontrados = agendamentos.filter(
      ag => ag.telefone === telefoneBusca
    );
    
    setAgendamentosCliente(encontrados);
    setMostrarMeusAgendamentos(true);
    
    if (encontrados.length === 0) {
      Alert.alert('Nenhum agendamento', 'Não encontramos agendamentos para este telefone');
    }
  };

  const AdminAgendamentoCard = ({ item }) => (
    <View style={styles.adminAgendamentoCard}>
      <View style={styles.agendamentoHeader}>
        <Text style={styles.adminAgendamentoServico}>{item.servico.nome}</Text>
        <TouchableOpacity onPress={() => cancelarAgendamentoAdmin(item.id)}>
          <Text style={styles.cancelarBtn}>❌ Cancelar</Text>
        </TouchableOpacity>
      </View>
      <Text style={styles.agendamentoCliente}>👤 {item.cliente}</Text>
      <Text style={styles.agendamentoData}>📅 {item.dataFormatada} às {item.horario}</Text>
      <Text style={styles.agendamentoTel}>📞 {item.telefone}</Text>
      <Text style={styles.agendamentoServicoInfo}>💅 {item.servico.nome} - {item.servico.preco}</Text>
      {item.observacao ? (
        <Text style={styles.agendamentoObs}>📝 {item.observacao}</Text>
      ) : null}
      <View style={styles.statusBadge}>
        <Text style={styles.statusText}>✅ {item.status}</Text>
      </View>
    </View>
  );

  const CardServico = ({ servico }) => (
    <TouchableOpacity 
      style={[
        styles.servicoCard,
        servicoSelecionado?.id === servico.id && styles.servicoCardSelecionado
      ]}
      onPress={() => setServicoSelecionado(servico)}
    >
      <Text style={styles.servicoIcon}>{servico.icon}</Text>
      <View style={styles.servicoInfo}>
        <Text style={styles.servicoNome}>{servico.nome}</Text>
        <Text style={styles.servicoDesc}>{servico.descricao}</Text>
        <View style={styles.servicoDetalhes}>
          <Text style={styles.servicoDuracao}>⏱️ {servico.duracao}</Text>
          <Text style={styles.servicoPreco}>💰 {servico.preco}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#E91E63" />
      
      <View style={styles.header}>
        <Text style={styles.titulo}>👁️ {PROFISSIONAL.loja}</Text>
        <Text style={styles.subtitulo}>por {PROFISSIONAL.nome}</Text>
        <Text style={styles.instagram}>{PROFISSIONAL.instagram}</Text>
        
        <TouchableOpacity 
          style={styles.botaoWhatsApp}
          onPress={() => abrirWhatsApp()}
        >
          <Text style={styles.botaoWhatsAppText}>💬 Fale comigo no WhatsApp</Text>
        </TouchableOpacity>
        
        {!modoAdmin ? (
          <TouchableOpacity 
            style={styles.botaoAdmin}
            onPress={() => setModalLoginVisible(true)}
          >
            <Text style={styles.botaoAdminText}>👩‍💼 Área da Rafa</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity 
            style={styles.botaoAdminLogout}
            onPress={fazerLogoutAdmin}
          >
            <Text style={styles.botaoAdminText}>🚪 Sair do modo Admin</Text>
          </TouchableOpacity>
        )}
      </View>

      {modoAdmin ? (
        <ScrollView style={styles.content}>
          <Text style={styles.sectionTitle}>📊 Painel da Rafa</Text>
          <View style={styles.statsCard}>
            <Text style={styles.statsNumber}>{agendamentos.length}</Text>
            <Text style={styles.statsLabel}>Total de Agendamentos</Text>
          </View>
          
          <Text style={styles.sectionTitle}>📋 Agendamentos</Text>
          {agendamentos.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={styles.emptyEmoji}>📅</Text>
              <Text style={styles.emptyText}>Nenhum agendamento ainda</Text>
            </View>
          ) : (
            agendamentos
              .sort((a, b) => new Date(a.data) - new Date(b.data))
              .map(item => <AdminAgendamentoCard key={item.id} item={item} />)
          )}
        </ScrollView>
      ) : (
        <>
          {!mostrarMeusAgendamentos ? (
            <ScrollView style={styles.content}>
              <View style={styles.buscaCard}>
                <Text style={styles.buscaTitulo}>🔍 Já tem agendamento?</Text>
                <Text style={styles.buscaSub}>Digite seu telefone para consultar</Text>
                <TextInput
                  style={styles.buscaInput}
                  placeholder="(11) 99999-9999"
                  value={telefoneBusca}
                  onChangeText={setTelefoneBusca}
                  keyboardType="phone-pad"
                />
                <TouchableOpacity 
                  style={styles.buscaBotao}
                  onPress={buscarAgendamentosPorTelefone}
                >
                  <Text style={styles.buscaBotaoText}>Consultar meus agendamentos</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.divider}>
                <View style={styles.dividerLine} />
                <Text style={styles.dividerText}>ou</Text>
                <View style={styles.dividerLine} />
              </View>

              <Text style={styles.sectionTitle}>💅 Nossos Serviços</Text>
              {SERVICOS.map(servico => (
                <CardServico key={servico.id} servico={servico} />
              ))}

              <TouchableOpacity 
                style={styles.botaoAgendar}
                onPress={() => setModalAgendamentoVisible(true)}
              >
                <Text style={styles.botaoAgendarText}>📅 Fazer Agendamento</Text>
              </TouchableOpacity>
            </ScrollView>
          ) : (
            <ScrollView style={styles.content}>
              <View style={styles.buscaHeader}>
                <Text style={styles.sectionTitle}>📌 Meus Agendamentos</Text>
                <TouchableOpacity 
                  onPress={() => {
                    setMostrarMeusAgendamentos(false);
                    setTelefoneBusca('');
                    setAgendamentosCliente([]);
                  }}
                >
                  <Text style={styles.voltarTexto}>← Voltar</Text>
                </TouchableOpacity>
              </View>

              {agendamentosCliente.length === 0 ? (
                <View style={styles.emptyState}>
                  <Text style={styles.emptyEmoji}>📅</Text>
                  <Text style={styles.emptyText}>Nenhum agendamento encontrado</Text>
                </View>
              ) : (
                agendamentosCliente.map(item => (
                  <View key={item.id} style={styles.clienteAgendamentoCard}>
                    <View style={styles.agendamentoHeader}>
                      <Text style={styles.clienteAgendamentoServico}>{item.servico.nome}</Text>
                      <TouchableOpacity onPress={() => cancelarAgendamentoCliente(item.id)}>
                        <Text style={styles.cancelarBtn}>❌ Cancelar</Text>
                      </TouchableOpacity>
                    </View>
                    <Text style={styles.agendamentoData}>📅 {item.dataFormatada} às {item.horario}</Text>
                    <Text style={styles.agendamentoServicoInfo}>💰 {item.servico.preco}</Text>
                    {item.observacao ? (
                      <Text style={styles.agendamentoObs}>📝 {item.observacao}</Text>
                    ) : null}
                    <View style={styles.statusBadgeCliente}>
                      <Text style={styles.statusTextCliente}>✅ Confirmado</Text>
                    </View>
                    
                    <TouchableOpacity 
                      style={styles.whatsAppClienteBotao}
                      onPress={() => abrirWhatsApp(`Olá ${PROFISSIONAL.nome}! Sou ${item.cliente} e tenho um agendamento ${item.servico.nome} no dia ${item.dataFormatada} às ${item.horario}. Tenho uma dúvida:`)}
                    >
                      <Text style={styles.whatsAppClienteText}>💬 Falar com a Rafa</Text>
                    </TouchableOpacity>
                  </View>
                ))
              )}
            </ScrollView>
          )}

          {/* Modal de Agendamento */}
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalAgendamentoVisible}
            onRequestClose={() => setModalAgendamentoVisible(false)}
          >
            <View style={styles.modalContainer}>
              <ScrollView style={styles.modalContent}>
                <Text style={styles.modalTitulo}>📝 Agendar na {PROFISSIONAL.loja}</Text>

                <Text style={styles.inputLabel}>Seu nome *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Digite seu nome completo"
                  value={nomeCliente}
                  onChangeText={setNomeCliente}
                />

                <Text style={styles.inputLabel}>WhatsApp/Telefone *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="(11) 99999-9999"
                  value={telefone}
                  onChangeText={setTelefone}
                  keyboardType="phone-pad"
                />

                <Text style={styles.inputLabel}>Serviço selecionado:</Text>
                <View style={styles.servicoSelecionadoView}>
                  <Text style={styles.servicoSelecionadoText}>
                    {servicoSelecionado ? `${servicoSelecionado.icon} ${servicoSelecionado.nome} - ${servicoSelecionado.preco}` : 'Nenhum serviço selecionado'}
                  </Text>
                </View>

                <Text style={styles.inputLabel}>Selecione a data *</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.datasContainer}>
                  {datasDisponiveis.map(data => (
                    <TouchableOpacity
                      key={data.id}
                      style={[
                        styles.dataCard,
                        dataSelecionada?.id === data.id && styles.dataCardSelecionado
                      ]}
                      onPress={() => setDataSelecionada(data)}
                    >
                      <Text style={[styles.dataDiaSemana, dataSelecionada?.id === data.id && styles.textoBranco]}>{data.diaSemana.substring(0,3)}</Text>
                      <Text style={[styles.dataDia, dataSelecionada?.id === data.id && styles.textoBranco]}>{data.dia}</Text>
                      <Text style={[styles.dataMes, dataSelecionada?.id === data.id && styles.textoBranco]}>{data.mes}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>

                <Text style={styles.inputLabel}>Selecione o horário *</Text>
                <View style={styles.horariosContainer}>
                  {HORARIOS.map(horario => {
                    const ocupado = agendamentos.some(
                      ag => ag.data === dataSelecionada?.dataCompleta && ag.horario === horario
                    );
                    return (
                      <TouchableOpacity
                        key={horario}
                        style={[
                          styles.horarioCard,
                          horarioSelecionado === horario && styles.horarioCardSelecionado,
                          ocupado && styles.horarioCardOcupado
                        ]}
                        onPress={() => !ocupado && setHorarioSelecionado(horario)}
                        disabled={ocupado}
                      >
                        <Text style={[
                          styles.horarioTexto,
                          ocupado && styles.horarioTextoOcupado
                        ]}>
                          {horario} {ocupado ? '❌' : ''}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>

                <Text style={styles.inputLabel}>Observação (opcional)</Text>
                <TextInput
                  style={[styles.input, styles.textArea]}
                  placeholder="Ex: Alergia a algum produto..."
                  value={observacao}
                  onChangeText={setObservacao}
                  multiline
                  numberOfLines={3}
                />

                <View style={styles.modalBotoes}>
                  <TouchableOpacity 
                    style={[styles.modalBotao, styles.botaoCancelar]}
                    onPress={() => setModalAgendamentoVisible(false)}
                  >
                    <Text style={styles.botaoCancelarText}>Cancelar</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[styles.modalBotao, styles.botaoConfirmar]}
                    onPress={fazerAgendamento}
                  >
                    <Text style={styles.botaoConfirmarText}>Confirmar</Text>
                  </TouchableOpacity>
                </View>
              </ScrollView>
            </View>
          </Modal>

          {/* Modal Login Admin */}
          <Modal
            transparent={true}
            visible={modalLoginVisible}
            onRequestClose={() => setModalLoginVisible(false)}
          >
            <View style={styles.modalContainer}>
              <View style={styles.modalLoginContent}>
                <Text style={styles.modalTitulo}>👩‍💼 Área da {PROFISSIONAL.nome}</Text>
                <Text style={styles.loginSub}>Digite sua senha para acessar</Text>
                <TextInput
                  style={styles.input}
                  placeholder="Senha"
                  secureTextEntry
                  value={senhaAdmin}
                  onChangeText={setSenhaAdmin}
                />
                <TouchableOpacity 
                  style={styles.botaoConfirmar}
                  onPress={fazerLoginAdmin}
                >
                  <Text style={styles.botaoConfirmarText}>Entrar</Text>
                </TouchableOpacity>
                <TouchableOpacity 
                  onPress={() => setModalLoginVisible(false)}
                >
                  <Text style={styles.fecharLogin}>Fechar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  header: {
    backgroundColor: '#E91E63',
    padding: 20,
    paddingTop: 40,
    alignItems: 'center',
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFF',
  },
  subtitulo: {
    fontSize: 12,
    color: '#FCE4EC',
    marginTop: 2,
  },
  instagram: {
    fontSize: 12,
    color: '#FCE4EC',
    marginTop: 2,
  },
  botaoWhatsApp: {
    marginTop: 10,
    backgroundColor: '#25D366',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 25,
  },
  botaoWhatsAppText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: 'bold',
  },
  botaoAdmin: {
    marginTop: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 15,
    paddingVertical: 6,
    borderRadius: 20,
  },
  botaoAdminLogout: {
    marginTop: 8,
    backgroundColor: '#C2185B',
    paddingHorizontal: 15,
    paddingVertical: 6,
    borderRadius: 20,
  },
  botaoAdminText: {
    color: '#FFF',
    fontSize: 11,
  },
  content: {
    flex: 1,
    padding: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
    marginTop: 10,
  },
  statsCard: {
    backgroundColor: '#E91E63',
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
  },
  statsNumber: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#FFF',
  },
  statsLabel: {
    fontSize: 14,
    color: '#FCE4EC',
  },
  servicoCard: {
    flexDirection: 'row',
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  servicoCardSelecionado: {
    borderColor: '#E91E63',
    borderWidth: 2,
    backgroundColor: '#FCE4EC',
  },
  servicoIcon: {
    fontSize: 40,
    marginRight: 15,
  },
  servicoInfo: {
    flex: 1,
  },
  servicoNome: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  servicoDesc: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  servicoDetalhes: {
    flexDirection: 'row',
    marginTop: 6,
    gap: 15,
  },
  servicoDuracao: {
    fontSize: 11,
    color: '#999',
  },
  servicoPreco: {
    fontSize: 11,
    color: '#E91E63',
    fontWeight: 'bold',
  },
  botaoAgendar: {
    backgroundColor: '#E91E63',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 30,
  },
  botaoAgendarText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFF',
  },
  adminAgendamentoCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  clienteAgendamentoCard: {
    backgroundColor: '#FFF',
    borderRadius: 12,
    padding: 15,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  agendamentoHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  adminAgendamentoServico: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#E91E63',
  },
  clienteAgendamentoServico: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#E91E63',
  },
  agendamentoServicoInfo: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  cancelarBtn: {
    fontSize: 12,
    color: '#E74C3C',
  },
  agendamentoCliente: {
    fontSize: 14,
    color: '#333',
    marginBottom: 5,
  },
  agendamentoData: {
    fontSize: 13,
    color: '#666',
    marginBottom: 3,
  },
  agendamentoTel: {
    fontSize: 13,
    color: '#666',
  },
  agendamentoObs: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
    fontStyle: 'italic',
  },
  statusBadge: {
    marginTop: 10,
    alignSelf: 'flex-start',
    backgroundColor: '#D5F5E3',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 15,
  },
  statusBadgeCliente: {
    marginTop: 10,
    alignSelf: 'flex-start',
    backgroundColor: '#D5F5E3',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 15,
  },
  statusText: {
    fontSize: 11,
    color: '#27AE60',
  },
  statusTextCliente: {
    fontSize: 11,
    color: '#27AE60',
  },
  whatsAppClienteBotao: {
    marginTop: 12,
    backgroundColor: '#25D366',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
  },
  whatsAppClienteText: {
    color: '#FFF',
    fontSize: 13,
    fontWeight: 'bold',
  },
  buscaCard: {
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 20,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  buscaTitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  buscaSub: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginTop: 5,
    marginBottom: 15,
  },
  buscaInput: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    marginBottom: 15,
  },
  buscaBotao: {
    backgroundColor: '#E91E63',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
  },
  buscaBotaoText: {
    color: '#FFF',
    fontSize: 14,
    fontWeight: 'bold',
  },
  buscaHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  voltarTexto: {
    color: '#E91E63',
    fontSize: 14,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#E0E0E0',
  },
  dividerText: {
    marginHorizontal: 10,
    color: '#999',
  },
  emptyState: {
    alignItems: 'center',
    padding: 40,
  },
  emptyEmoji: {
    fontSize: 60,
    marginBottom: 15,
  },
  emptyText: {
    fontSize: 18,
    color: '#999',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
  },
  modalContent: {
    backgroundColor: '#FFF',
    margin: 20,
    borderRadius: 20,
    padding: 20,
    maxHeight: '90%',
  },
  modalLoginContent: {
    backgroundColor: '#FFF',
    margin: 40,
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
  },
  modalTitulo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#E91E63',
    marginBottom: 20,
    textAlign: 'center',
  },
  loginSub: {
    fontSize: 14,
    color: '#666',
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 12,
    marginBottom: 4,
  },
  input: {
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#FFF',
  },
  textArea: {
    height: 80,
    textAlignVertical: 'top',
  },
  servicoSelecionadoView: {
    borderWidth: 1,
    borderColor: '#E91E63',
    borderRadius: 10,
    padding: 12,
    backgroundColor: '#FCE4EC',
    marginBottom: 10,
  },
  servicoSelecionadoText: {
    fontSize: 14,
    color: '#E91E63',
  },
  datasContainer: {
    flexDirection: 'row',
    marginVertical: 10,
  },
  dataCard: {
    backgroundColor: '#F0F0F0',
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    marginRight: 10,
    minWidth: 70,
  },
  dataCardSelecionado: {
    backgroundColor: '#E91E63',
  },
  dataDiaSemana: {
    fontSize: 12,
    color: '#666',
  },
  dataDia: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  dataMes: {
    fontSize: 11,
    color: '#666',
  },
  textoBranco: {
    color: '#FFF',
  },
  horariosContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginVertical: 10,
  },
  horarioCard: {
    backgroundColor: '#F0F0F0',
    borderRadius: 8,
    padding: 10,
    margin: 5,
    minWidth: 70,
    alignItems: 'center',
  },
  horarioCardSelecionado: {
    backgroundColor: '#E91E63',
  },
  horarioCardOcupado: {
    backgroundColor: '#FFCDD2',
    opacity: 0.6,
  },
  horarioTexto: {
    fontSize: 14,
    color: '#333',
  },
  horarioTextoOcupado: {
    color: '#999',
    textDecorationLine: 'line-through',
  },
  modalBotoes: {
    flexDirection: 'row',
    marginTop: 25,
    marginBottom: 15,
    gap: 10,
  },
  modalBotao: {
    flex: 1,
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  botaoCancelar: {
    backgroundColor: '#F5F5F5',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  botaoCancelarText: {
    color: '#666',
    fontSize: 16,
  },
  botaoConfirmar: {
    backgroundColor: '#E91E63',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  botaoConfirmarText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  fecharLogin: {
    marginTop: 15,
    color: '#999',
  },
});